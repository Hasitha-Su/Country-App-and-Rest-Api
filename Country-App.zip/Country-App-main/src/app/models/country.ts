export class Country {
    id: number;
    countryName: string;
}
