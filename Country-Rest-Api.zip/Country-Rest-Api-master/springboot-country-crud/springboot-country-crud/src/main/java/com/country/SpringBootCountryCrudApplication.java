package com.country;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootCountryCrudApplication {
	public static void main(String[] args) {
		SpringApplication.run(SpringBootCountryCrudApplication.class, args);
	}
}