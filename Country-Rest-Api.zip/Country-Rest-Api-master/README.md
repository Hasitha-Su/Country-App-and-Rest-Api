# Country-Rest-Api
Rest API using spring boot with basic http CRUD operations (Used H2 as the DB).
Country-spring-boot.postman_collection.json file is a postman collection for testing this web appilcation
